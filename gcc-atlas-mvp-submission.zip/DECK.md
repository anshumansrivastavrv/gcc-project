# GCC Atlas — India GCC Intelligence

## Slide 1 — GCC decisions need a shared evidence base

India had **2,117 GCCs across 3,728 operating units** in FY2026, according to the NASSCOM–Zinnov landscape report. That is a large market, but the decision inputs for entering it remain spread across policy documents, property reports, recruiters, advisors, filings and private networks.

**GCC Atlas is a source-linked workspace for building a defensible India market-entry shortlist.**

*Evidence note: FY2026 landscape numbers are industry estimates as of March 2026. GCC counts vary with definition and whether the unit counted is a company-level GCC or an operating centre.*

## Slide 2 — The entry decision crosses fragmented information

| Decision input | Where teams look today | What is hard to compare |
|---|---|---|
| GCC landscape and pipeline | Industry reports, company announcements, filings, search | Definition, status, location, confidence and recency |
| City and talent | Broker decks, recruiters, reports, internal teams | Neighbourhood, role mix, seniority, date and methodology |
| Office costs | Landlords, brokers, market reports | Grade, submarket, lease term, fit-out and incentives |
| State policy | Government portals, advisors, legal teams | Current validity, eligibility, caps and application process |
| Provider track record | Referrals, RFPs and vendor claims | Comparable proof, client permission, recency and outcomes |

The asymmetry is between parties who repeatedly collect and negotiate this information and new entrants making a one-time, high-stakes decision with less context. Incumbent advisors and brokers may hold valuable knowledge; the product opportunity is to make evidence and assumptions easier to inspect across the workflow.

## Slide 3 — Who bears the cost, and how it is measured

| Stakeholder | Current workaround | Cost or risk to measure |
|---|---|---|
| Global company entering India | Lead advisor, peer referrals, parallel RFPs and spreadsheets | Research hours, elapsed time to shortlist, rework and late changes |
| GCC strategy / location lead | Broker decks plus internal talent and finance analysis | Non-comparable assumptions; sensitivity to location and role mix |
| State investment agency | Manual outreach and event-led pipeline | Staff time spent qualifying leads; weak visibility into competing locations |
| Service provider | Relationship selling and self-reported marketing | Cost of discovery and difficulty proving relevant delivery experience |
| Investor / researcher | Reports, filings and web search | Reconciliation effort and stale or contradictory records |

**We do not yet have defensible evidence for a rupee or weeks-saved estimate.** Treat the magnitude as an open validation question. In a pilot, log baseline research hours, elapsed days, number of sources checked, duplicated diligence and shortlist changes; compare the same measures using Atlas. Report the sample and method before claiming savings.

## Slide 4 — Market scale is established; local decision data is uneven

- **2,117 GCCs; 3,728 operating units; 2.36 million professionals; $98.4B revenue** — FY2026 NASSCOM–Zinnov estimate, data as of March 2026.
- In FY2024, the same research series counted **1,700+ GCCs and 2,975+ centres**. The two editions illustrate why a product must show date, definition and unit of count.
- JLL’s February 2026 India GCC Guide says Bengaluru has 900+ GCC units and 34–39% of GCC activity; it reports Hyderabad at 20–23% and Pune at 15–20%. These are broker-research estimates, not directly comparable with the entity count above; use them as contextual signals, not a city score.
- JLL reports **31 million sq. ft. of GCC leasing in 2025**, a record, showing that real estate is an active decision input. Leasing volume does not by itself establish city-level rent or affordability.

**Implication:** lead with provenance and comparability. Do not imply that one headline count or composite city score is a complete source of truth.

## Slide 5 — Prioritise the decision workflow before the directory

| Priority | Opportunity | Why it matters | Main constraint |
|---|---|---|---|
| 1 | City and market-entry comparison | High-consequence decision that combines talent, real estate, policy and ecosystem inputs | Comparable, current data by submarket and role is difficult |
| 2 | Policy and incentive monitoring | State schemes are fragmented and conditions affect the business case | High update and interpretation burden; legal review required |
| 3 | Provider diligence | Referrals dominate discovery, but buyers need evidence of relevant delivery | References and outcomes are often confidential |
| 4 | Office and talent benchmarks | Critical to operating-cost and hiring plans | Geography, role mix and assumptions must match |
| 5 | Upcoming GCC signals | Could become a differentiated pipeline dataset | Signals are noisy; forecasts need validation and confidence labels |

This is a **product hypothesis**, not proven demand ranking. Validate order through buyer interviews and observed workflow use. Start where a decision owner can use the output and check its sources in one session.

## Slide 6 — Build an evidence workspace for the first decision

**First user:** a strategy, location or real-estate lead at a global firm evaluating an India setup or expansion.

**Initial workflow:** define function, headcount and candidate cities → compare explicit inputs → inspect source and date → shortlist providers or policy questions → export a decision brief with assumptions and open diligence.

The Atlas evidence record should include source URL, source date, checked date, geography, unit, methodology, evidence status, reviewer and change history. Separate primary evidence, reputable secondary estimates, user submissions and illustrative demo inputs. A composite score should never hide missing or incomparable inputs.

**Initial buyer to test:** specialist market-entry advisors who repeat this research across clients. They can validate whether a reusable evidence base saves work and will pay for it. Do not assume they are the buyer until tested.

## Slide 7 — Positioning by stakeholder

| Stakeholder | Why choose Atlas over today’s workaround |
|---|---|
| GCC entrant | See sources, dates and assumptions together before spending on a full diligence engagement |
| Advisor | Reuse a maintained evidence base and produce a traceable client brief instead of rebuilding a spreadsheet |
| State agency | Compare public signals and record qualification status; avoid treating an inferred lead as committed pipeline |
| Provider | Show relevant, reviewed evidence and capability by city/function; no paid rank in the trust layer |
| Researcher / investor | Trace a claim to source, date and definition, and flag conflicting counts |

**Position:** an evidence and workflow layer between scattered public signals and an India GCC market-entry decision. It complements specialist advice; it does not replace legal, tax or site diligence.

## Slide 8 — What the working prototype demonstrates

- React/Vite app with GCC explorer, adjustable city priorities, provider engagement evidence, a public-signal pipeline, state policy leads and an interactive market-entry brief.
- City ranking uses user-set weights over illustrative city inputs. Pipeline coverage sums declared signal weights; it is not a probability or forecast.
- Provider submissions include a source link and self-reported delivery responses. A link does not mean the claim was independently verified.
- The brief combines city priorities, pipeline leads, provider evidence and policy leads, and exports as text. Provider evidence, pipeline edits and city weights are stored in the current browser only.
- Flask API and MySQL support the existing GCC, provider and incentive records; the UI falls back to seeded demo data when the API is unavailable.
- Fictional companies and providers, sample scores, and sample pipeline entries demonstrate interaction only. They are not a verified market database or recommendations.

**Prototype boundary:** policy entries are research leads, not validated entitlements. The demo has no authentication, evidence review queue, audit log, ingestion pipeline or production-grade source monitoring. Browser-stored workflows do not sync across users or devices.

## Slide 9 — Data quality is the product work

| Data surface | Minimum useful record | Verification standard |
|---|---|---|
| GCC / pipeline | Entity, city, status, signal date, source and confidence | Primary announcement/filing or multiple independent signals; label inferred leads |
| Office cost | Submarket, grade, rent basis, lease term, fit-out and date | Source and comparable assumptions shown; do not compare unlike quotes |
| Talent | Role, level, skill, location, salary basis and date | Methodology and sample/proxy disclosed |
| Provider proof | Service, city, sector, engagement date and evidence | Public case, reviewed reference or permissioned client confirmation |
| Incentive | Official instrument, eligibility, caps, process, effective date and status | Official document checked; periodic review and explicit legal verification step |

## Slide 10 — Pilot and success measures

Run a 4–6 week pilot with **3 advisors, 3 GCC/location leaders and 1 ecosystem stakeholder**. Give each a bounded city-pair decision and capture the current workflow before showing Atlas.

Measure baseline versus Atlas-assisted work: time to first shortlist, research hours, critical claims with traceable sources, source correction rate, shortlist changes and repeat use. Record participant count and task scope. A promising signal is repeated use and a decision owner identifying a material improvement; set a numeric threshold with participants before the pilot, not after seeing results.

**Continue** if users return to the same evidence workflow and rely on it to prepare real decisions. **Narrow or stop** if they value bespoke advice but do not reuse the dataset or workflow.

## Slide 11 — Research references and limits

1. NASSCOM–Zinnov, [India GCC Landscape Report — FY2026](https://zinnov.com/centers-of-excellence/zinnov-nasscom-india-gcc-landscape-2026-report/), data as of March 2026. Industry research; full report access may require registration.
2. NASSCOM, [India GCC Landscape Report — The 5 Year Journey](https://community.nasscom.in/index.php/communities/nasscom-insights/india-gcc-landscape-report-5-year-journey?page=7), published 11 September 2024.
3. JLL, [India GCC leasing hits record 31 million sq. ft. in 2025](https://www.jll.com/en-in/newsroom/india-s-gcc-expansion-hits-record-31-million), published 17 February 2026; includes city activity shares and GCC leasing. Broker research; definitions differ from GCC entity counts.
4. D&B, [Rethinking the Future of Global Capability Centers 2025](https://www.dnb.co.in/files/reports/DNB-Rethinking-the-Future-of-Global-Capability-Centers-2025.pdf), pp. 21–24; secondary synthesis citing multiple sources, included as a cross-check only.
5. Government of Karnataka, [GCC Policy 2024–2029 application portal](https://registration.eitbt.karnataka.gov.in/gcc/register). The deck does not assert specific subsidy eligibility; consult current policy and operational guidelines.

**Research limits:** industry counts and city shares use different definitions, dates and methodologies. Market size and forecast figures are not independently audited by this project. Pilot impact, willingness to pay and provider proof remain unvalidated.
