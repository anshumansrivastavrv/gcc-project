CREATE DATABASE IF NOT EXISTS gcc_atlas CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE gcc_atlas;

DROP TABLE IF EXISTS incentives;
DROP TABLE IF EXISTS providers;
DROP TABLE IF EXISTS gccs;
DROP TABLE IF EXISTS cities;

CREATE TABLE cities (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  state_name VARCHAR(80) NOT NULL,
  talent_score TINYINT NOT NULL,
  ecosystem_score TINYINT NOT NULL,
  cost_score TINYINT NOT NULL,
  infrastructure_score TINYINT NOT NULL,
  rationale TEXT NOT NULL,
  evidence_label VARCHAR(40) NOT NULL DEFAULT 'DEMO / illustrative'
);

CREATE TABLE gccs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_name VARCHAR(180) NOT NULL,
  sector VARCHAR(100) NOT NULL,
  city VARCHAR(80) NOT NULL,
  functions TEXT NOT NULL,
  status VARCHAR(60) NOT NULL,
  evidence_label VARCHAR(40) NOT NULL DEFAULT 'DEMO',
  source_name VARCHAR(180) NOT NULL DEFAULT 'Illustrative seed record',
  source_url TEXT,
  verified_on DATE NULL,
  notes TEXT
);

CREATE TABLE providers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(180) NOT NULL,
  category VARCHAR(100) NOT NULL,
  cities VARCHAR(255) NOT NULL,
  services TEXT NOT NULL,
  evidence_label VARCHAR(40) NOT NULL DEFAULT 'DEMO',
  source_name VARCHAR(180) NOT NULL DEFAULT 'Illustrative seed record',
  source_url TEXT,
  verified_on DATE NULL,
  notes TEXT
);

CREATE TABLE incentives (
  id INT AUTO_INCREMENT PRIMARY KEY,
  state_name VARCHAR(80) NOT NULL,
  scheme_name VARCHAR(220) NOT NULL,
  eligible_activity VARCHAR(220) NOT NULL,
  benefit_summary TEXT NOT NULL,
  conditions TEXT NOT NULL,
  source_name VARCHAR(180) NOT NULL,
  source_url TEXT NOT NULL,
  verified_on DATE NULL,
  evidence_label VARCHAR(40) NOT NULL DEFAULT 'RESEARCH LEAD — verify'
);

INSERT INTO cities(name,state_name,talent_score,ecosystem_score,cost_score,infrastructure_score,rationale,evidence_label) VALUES
('Bengaluru','Karnataka',95,96,62,83,'Illustrative score: deep technology, product, engineering and BFSI ecosystem; validate neighbourhood-level talent and occupancy costs.','DEMO / illustrative'),
('Hyderabad','Telangana',88,85,76,85,'Illustrative score: technology and life-sciences depth with a strong office market; validate role-specific supply and policy fit.','DEMO / illustrative'),
('Pune','Maharashtra',82,79,78,79,'Illustrative score: engineering, automotive, technology and BFSI talent; validate senior leadership availability.','DEMO / illustrative'),
('Chennai','Tamil Nadu',80,76,80,78,'Illustrative score: manufacturing, automotive, engineering and technology ecosystem; validate niche talent and commute needs.','DEMO / illustrative');

INSERT INTO gccs(company_name,sector,city,functions,status,evidence_label,source_name,source_url,notes) VALUES
('Northstar Fintech (fictional)','BFSI / Fintech','Bengaluru','Engineering; Risk Analytics; Product','Illustrative record','DEMO','Synthetic seed data','', 'Fictional example used to demonstrate search and filtering.'),
('Aster BioSystems (fictional)','Life Sciences','Hyderabad','Data Science; Clinical Operations','Illustrative record','DEMO','Synthetic seed data','', 'Fictional example used to demonstrate search and filtering.'),
('Helio Mobility (fictional)','Manufacturing / ER&D','Pune','Embedded Engineering; Analytics','Illustrative record','DEMO','Synthetic seed data','', 'Fictional example used to demonstrate search and filtering.'),
('Cobalt Cloud (fictional)','Technology','Chennai','Cloud Platform; QA; Security','Illustrative record','DEMO','Synthetic seed data','', 'Fictional example used to demonstrate search and filtering.');

INSERT INTO providers(name,category,cities,services,evidence_label,source_name,source_url,notes) VALUES
('Example Legal Partners (fictional)','Legal & entity setup','Bengaluru, Hyderabad, Pune, Chennai','Entity formation; compliance checklist; contract review','DEMO','Synthetic seed data',NULL,'Not a real firm; placeholder for product testing.'),
('Example Talent Studio (fictional)','Recruitment','Bengaluru, Hyderabad, Pune','Leadership hiring; engineering recruitment; market mapping','DEMO','Synthetic seed data',NULL,'Not a real firm; placeholder for product testing.'),
('Example Workplace Advisors (fictional)','Real estate','Bengaluru, Hyderabad, Chennai','Office search; lease comparison; workplace strategy','DEMO','Synthetic seed data',NULL,'Not a real firm; placeholder for product testing.'),
('Example Employer Services (fictional)','EOR / payroll','Pan-India','Employer of record; payroll; onboarding','DEMO','Synthetic seed data',NULL,'Not a real firm; placeholder for product testing.');

INSERT INTO incentives(state_name,scheme_name,eligible_activity,benefit_summary,conditions,source_name,source_url,verified_on,evidence_label) VALUES
('Karnataka','Karnataka GCC Policy 2024–29','GCCs; innovation; skilling; expansion beyond Bengaluru','Policy includes multiple support measures; exact benefit depends on scheme, location and eligibility.','Confirm current operational guidelines, applicant type, location, caps, claim window and approval route with the official policy and agency.','Karnataka GCC Policy overview','https://itbtst.karnataka.gov.in/','2026-10-10','RESEARCH LEAD — verify'),
('Maharashtra','Maharashtra Global Capability Centre Policy 2025','GCC establishment and expansion','Official state portal lists the 2025 GCC policy and operational guidelines; benefit details must be checked against the current policy documents.','Verify current guidelines, eligible districts, employment/investment thresholds, application windows and whether the applicant qualifies.','Maharashtra Industries, Investment & Services Department','https://industry.maharashtra.gov.in/en/services/policies','2026-10-10','RESEARCH LEAD — verify'),
('Telangana','Telangana ICT Policy (policy-cycle review required)','IT / ITeS and related activities','Potential policy alignment to investigate; no monetary benefit is asserted in this record.','Confirm whether policy terms remain current and whether a GCC-specific scheme applies before relying on any benefit.','Telangana IT & C Department','https://it.telangana.gov.in/','2026-10-10','RESEARCH LEAD — verify');
