import os
from contextlib import contextmanager
from typing import Any

import mysql.connector
from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS
from mysql.connector import Error

load_dotenv()

app = Flask(__name__)
CORS(
    app,
    origins=os.getenv("CLIENT_ORIGIN", "http://localhost:5173"),
    methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
)


@contextmanager
def get_connection():
    connection = mysql.connector.connect(
        host=os.getenv("DB_HOST", "127.0.0.1"),
        port=int(os.getenv("DB_PORT", "3306")),
        user=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        database=os.getenv("DB_NAME", "gcc_atlas"),
    )
    try:
        yield connection
    finally:
        if connection.is_connected():
            connection.close()


def query_all(sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
    with get_connection() as connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        cursor.close()
        return rows


def query_one(sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
    rows = query_all(sql, params)
    return rows[0] if rows else None


def execute(sql: str, params: tuple[Any, ...] = ()) -> int:
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(sql, params)
        connection.commit()
        last_id = cursor.lastrowid
        cursor.close()
        return int(last_id or 0)


def like(value: Any) -> str:
    return f"%{str(value or '')[:120]}%"


@app.get("/api/health")
def health():
    query_one("SELECT 1 AS ok")
    return jsonify(
        {
            "ok": True,
            "service": "GCC Atlas API",
            "dataPolicy": "Seed records are labelled demo/research leads",
        }
    )


@app.get("/api/cities")
def cities():
    return jsonify(query_all("SELECT * FROM cities ORDER BY talent_score DESC"))


@app.get("/api/gccs")
def gccs():
    q = request.args.get("q", "")
    city = request.args.get("city", "")
    sector = request.args.get("sector", "")
    return jsonify(
        query_all(
            """
            SELECT * FROM gccs
            WHERE (%s = '' OR company_name LIKE %s OR functions LIKE %s OR sector LIKE %s)
              AND (%s = '' OR city = %s)
              AND (%s = '' OR sector = %s)
            ORDER BY city, company_name
            """,
            (q, like(q), like(q), like(q), city, city, sector, sector),
        )
    )


@app.post("/api/gccs")
def create_gcc():
    body = request.get_json(silent=True) or {}
    required = ("company_name", "sector", "city", "functions")
    if any(not body.get(field) for field in required):
        return jsonify({"error": "company_name, sector, city and functions are required"}), 400

    record_id = execute(
        """
        INSERT INTO gccs
          (company_name, sector, city, functions, status, evidence_label,
           source_name, source_url, verified_on, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            body["company_name"],
            body["sector"],
            body["city"],
            body["functions"],
            body.get("status", "Research lead"),
            body.get("evidence_label", "UNVERIFIED"),
            body.get("source_name", "User submission"),
            body.get("source_url"),
            body.get("verified_on"),
            body.get("notes", ""),
        ),
    )
    return jsonify(query_one("SELECT * FROM gccs WHERE id = %s", (record_id,))), 201


def update_record(table: str, record_id: str, allowed_fields: set[str]):
    body = request.get_json(silent=True) or {}
    fields = [key for key in body if key in allowed_fields]
    if not fields:
        return jsonify({"error": "No editable fields supplied"}), 400

    assignments = ", ".join(f"`{field}` = %s" for field in fields)
    params = tuple(body[field] for field in fields) + (record_id,)
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(f"UPDATE `{table}` SET {assignments} WHERE id = %s", params)
        if cursor.rowcount == 0:
            connection.rollback()
            cursor.close()
            return jsonify({"error": "Record not found"}), 404
        connection.commit()
        cursor.close()
    return jsonify(query_one(f"SELECT * FROM `{table}` WHERE id = %s", (record_id,)))


def delete_record(table: str, record_id: str):
    with get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(f"DELETE FROM `{table}` WHERE id = %s", (record_id,))
        if cursor.rowcount == 0:
            connection.rollback()
            cursor.close()
            return jsonify({"error": "Record not found"}), 404
        connection.commit()
        cursor.close()
    return "", 204


@app.patch("/api/gccs/<int:record_id>")
def update_gcc(record_id: int):
    return update_record(
        "gccs",
        str(record_id),
        {
            "company_name",
            "sector",
            "city",
            "functions",
            "status",
            "evidence_label",
            "source_name",
            "source_url",
            "verified_on",
            "notes",
        },
    )


@app.delete("/api/gccs/<int:record_id>")
def delete_gcc(record_id: int):
    return delete_record("gccs", str(record_id))


@app.get("/api/providers")
def providers():
    q = request.args.get("q", "")
    city = request.args.get("city", "")
    category = request.args.get("category", "")
    return jsonify(
        query_all(
            """
            SELECT * FROM providers
            WHERE (%s = '' OR name LIKE %s OR services LIKE %s OR category LIKE %s)
              AND (%s = '' OR cities LIKE %s)
              AND (%s = '' OR category = %s)
            ORDER BY category, name
            """,
            (q, like(q), like(q), like(q), city, like(city), category, category),
        )
    )


@app.post("/api/providers")
def create_provider():
    body = request.get_json(silent=True) or {}
    required = ("name", "category", "cities", "services")
    if any(not body.get(field) for field in required):
        return jsonify({"error": "name, category, cities and services are required"}), 400

    record_id = execute(
        """
        INSERT INTO providers
          (name, category, cities, services, evidence_label, source_name,
           source_url, verified_on, notes)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            body["name"],
            body["category"],
            body["cities"],
            body["services"],
            body.get("evidence_label", "UNVERIFIED"),
            body.get("source_name", "User submission"),
            body.get("source_url"),
            body.get("verified_on"),
            body.get("notes", ""),
        ),
    )
    return jsonify(query_one("SELECT * FROM providers WHERE id = %s", (record_id,))), 201


@app.patch("/api/providers/<int:record_id>")
def update_provider(record_id: int):
    return update_record(
        "providers",
        str(record_id),
        {
            "name",
            "category",
            "cities",
            "services",
            "evidence_label",
            "source_name",
            "source_url",
            "verified_on",
            "notes",
        },
    )


@app.delete("/api/providers/<int:record_id>")
def delete_provider(record_id: int):
    return delete_record("providers", str(record_id))


@app.get("/api/incentives")
def incentives():
    state = request.args.get("state", "")
    return jsonify(
        query_all(
            "SELECT * FROM incentives WHERE (%s = '' OR state_name = %s) ORDER BY state_name",
            (state, state),
        )
    )


@app.post("/api/incentives")
def create_incentive():
    body = request.get_json(silent=True) or {}
    required = (
        "state_name",
        "scheme_name",
        "eligible_activity",
        "benefit_summary",
        "conditions",
        "source_name",
        "source_url",
    )
    if any(not body.get(field) for field in required):
        return jsonify({"error": "Required incentive fields missing"}), 400

    record_id = execute(
        """
        INSERT INTO incentives
          (state_name, scheme_name, eligible_activity, benefit_summary, conditions,
           source_name, source_url, verified_on, evidence_label)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """,
        (
            body["state_name"],
            body["scheme_name"],
            body["eligible_activity"],
            body["benefit_summary"],
            body["conditions"],
            body["source_name"],
            body["source_url"],
            body.get("verified_on"),
            body.get("evidence_label", "RESEARCH LEAD — verify"),
        ),
    )
    return jsonify(query_one("SELECT * FROM incentives WHERE id = %s", (record_id,))), 201


@app.get("/api/brief")
def brief():
    city_name = request.args.get("city", "Bengaluru")
    try:
        headcount = max(1, min(50000, int(request.args.get("headcount", "200"))))
    except ValueError:
        headcount = 200
    sector = request.args.get("sector", "Technology")
    city = query_one("SELECT * FROM cities WHERE name = %s", (city_name,))
    incentives_for_state = query_all(
        """
        SELECT state_name, scheme_name, source_name, source_url, evidence_label
        FROM incentives WHERE state_name = %s
        """,
        ((city or {}).get("state_name", "Karnataka"),),
    )
    return jsonify(
        {
            "title": f"India GCC entry brief — {city_name}",
            "assumptions": {"headcount": headcount, "sector": sector, "city": city_name},
            "city": city,
            "incentives": incentives_for_state,
            "disclaimer": (
                "Decision-support draft only. Scores are illustrative demo data. Verify all "
                "policy eligibility, rent, salary and legal matters with primary sources and "
                "qualified advisers."
            ),
        }
    )


@app.errorhandler(Error)
def handle_database_error(error):
    app.logger.exception("Database request failed", exc_info=error)
    return jsonify({"error": "Database request failed"}), 503


@app.errorhandler(Exception)
def handle_unexpected_error(error):
    app.logger.exception("Unexpected server error", exc_info=error)
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "4000")), debug=os.getenv("FLASK_DEBUG") == "1")
