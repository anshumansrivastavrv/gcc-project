import React, { useMemo, useState } from 'react';
import { ExternalLink, Plus, ShieldCheck } from 'lucide-react';

const load = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
};
const save = (key, value) => {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* Private browsing may block storage. */ }
};

const DIMENSIONS = [
  ['talent_score', 'Talent depth'],
  ['cost_score', 'Cost attractiveness'],
  ['infrastructure_score', 'Infrastructure'],
  ['ecosystem_score', 'Ecosystem maturity'],
];
const PIPELINE_SIGNALS = [
  ['Hiring for India roles', 3],
  ['India leader named', 3],
  ['Entity registered', 2],
  ['Press or earnings mention', 1],
];
const DEMO_PIPELINE = [
  { id: 'demo-x', company: 'Sample Co X (fictional)', source_url: '', signals: [true, true, true, false], demo: true },
  { id: 'demo-y', company: 'Sample Co Y (fictional)', source_url: '', signals: [true, false, false, true], demo: true },
  { id: 'demo-z', company: 'Sample Co Z (fictional)', source_url: '', signals: [false, false, false, true], demo: true },
];

export function rankCities(cities) {
  const weights = load('gcc-atlas-city-weights', [3, 3, 3, 3]);
  const total = weights.reduce((sum, value) => sum + value, 0) || 1;
  return cities.map(city => ({
    ...city,
    illustrative_fit: Math.round(DIMENSIONS.reduce((sum, [key], index) => sum + (Number(city[key]) || 0) * weights[index], 0) / total),
  })).sort((a, b) => b.illustrative_fit - a.illustrative_fit);
}

export function getPipelineLeads() { return load('gcc-atlas-pipeline', DEMO_PIPELINE); }
export function getProviderEvidence() { return load('gcc-atlas-provider-evidence', []); }

export function CityPriorityPanel({ cities, onSelect }) {
  const [weights, setWeights] = useState(() => load('gcc-atlas-city-weights', [3, 3, 3, 3]));
  const ranked = useMemo(() => {
    const total = weights.reduce((sum, value) => sum + Number(value), 0) || 1;
    return cities.map(city => ({
      ...city,
      illustrative_fit: Math.round(DIMENSIONS.reduce((sum, [key], index) => sum + (Number(city[key]) || 0) * Number(weights[index]), 0) / total),
    })).sort((a, b) => b.illustrative_fit - a.illustrative_fit);
  }, [cities, weights]);
  function changeWeight(index, value) {
    const next = weights.map((weight, i) => i === index ? Number(value) : weight);
    setWeights(next);
    save('gcc-atlas-city-weights', next);
  }
  return <section className="panel workflow-panel">
    <div className="panel-head"><div><h2>Rank cities for your priorities</h2><p>Scores use illustrative inputs. They are not sourced rankings.</p></div><span className="badge amber">DEMO SCORES</span></div>
    <div className="priority-grid">{DIMENSIONS.map(([key, label], index) => <label className="priority-control" key={key}><span>{label}</span><b>{weights[index]}</b><input aria-label={`${label} priority`} type="range" min="0" max="5" value={weights[index]} onChange={event => changeWeight(index, event.target.value)} /></label>)}</div>
    <div className="table-wrap"><table><thead><tr><th>Rank</th><th>City</th><th>Illustrative fit</th><th></th></tr></thead><tbody>{ranked.map((city, index) => <tr key={city.name}><td>{index + 1}</td><td><b>{city.name}</b><small>{city.state_name}</small></td><td>{city.illustrative_fit} / 100</td><td><button className="text-btn" onClick={() => onSelect(city.name)}>Inspect</button></td></tr>)}</tbody></table></div>
  </section>;
}

export function ProviderLedger({ providers }) {
  const [records, setRecords] = useState(() => load('gcc-atlas-provider-evidence', []));
  const [form, setForm] = useState({ provider_id: providers[0]?.id ?? '', on_time: false, on_budget: false, would_reuse: false, evidence_url: '' });
  function submit(event) {
    event.preventDefault();
    const provider = providers.find(item => String(item.id) === String(form.provider_id));
    if (!provider || !form.evidence_url.trim()) return;
    const next = [{ ...form, id: Date.now(), provider_id: provider.id, evidence_url: form.evidence_url.trim(), submitted_on: new Date().toISOString().slice(0, 10) }, ...records];
    setRecords(next); save('gcc-atlas-provider-evidence', next);
    setForm(value => ({ ...value, evidence_url: '', on_time: false, on_budget: false, would_reuse: false }));
  }
  const summaries = providers.map(provider => {
    const linked = records.filter(record => String(record.provider_id) === String(provider.id));
    const points = linked.reduce((sum, record) => sum + ['on_time', 'on_budget', 'would_reuse'].filter(key => record[key]).length, 0);
    return { provider, linked, score: linked.length ? Math.round(points / (linked.length * 3) * 100) : null };
  });
  return <section className="panel workflow-panel">
    <div className="panel-head"><div><h2>Provider engagement evidence</h2><p>Self-reported responses with a supporting link; not independently verified.</p></div><span className="badge">{records.length} entries</span></div>
    <div className="table-wrap"><table><thead><tr><th>Provider</th><th>Evidence-linked engagements</th><th>Self-reported score</th></tr></thead><tbody>{summaries.map(({ provider, linked, score }) => <tr key={provider.id}><td><b>{provider.name}</b></td><td>{linked.length}</td><td>{score === null ? 'No evidence' : `${score} / 100`}</td></tr>)}</tbody></table></div>
    <form className="evidence-form" onSubmit={submit}>
      <label>Provider<select value={form.provider_id} onChange={event => setForm({ ...form, provider_id: event.target.value })}>{providers.map(provider => <option key={provider.id} value={provider.id}>{provider.name}</option>)}</select></label>
      <label>Evidence URL<input type="url" required placeholder="https://…" value={form.evidence_url} onChange={event => setForm({ ...form, evidence_url: event.target.value })} /></label>
      <div className="evidence-checks">{[['on_time', 'On time'], ['on_budget', 'On budget'], ['would_reuse', 'Would reuse']].map(([key, label]) => <label key={key}><input type="checkbox" checked={form[key]} onChange={event => setForm({ ...form, [key]: event.target.checked })} /> {label}</label>)}</div>
      <button className="btn primary" type="submit"><Plus size={15} /> Add evidence</button>
    </form>
    {records.length === 0 ? <p className="empty-note">No engagement evidence added.</p> : <div className="table-wrap"><table><thead><tr><th>Provider</th><th>Responses</th><th>Added</th><th>Evidence</th></tr></thead><tbody>{records.map(record => { const provider = providers.find(item => String(item.id) === String(record.provider_id)); const points = ['on_time', 'on_budget', 'would_reuse'].filter(key => record[key]).length; return <tr key={record.id}><td><b>{provider?.name || 'Provider removed'}</b></td><td>{points} / 3</td><td>{record.submitted_on}</td><td><a href={record.evidence_url} target="_blank" rel="noreferrer">Open link <ExternalLink size={12} /></a></td></tr>; })}</tbody></table></div>}
    <div className="disclaimer"><ShieldCheck size={16} /><span>Adding a link does not verify a claim. Keep client permission and independent review outside this demo workflow.</span></div>
  </section>;
}

export function PipelinePanel() {
  const [leads, setLeads] = useState(() => getPipelineLeads());
  const [company, setCompany] = useState('');
  const [source, setSource] = useState('');
  function updateSignal(id, index, checked) {
    const next = leads.map(lead => lead.id === id ? { ...lead, signals: lead.signals.map((value, i) => i === index ? checked : value) } : lead);
    setLeads(next); save('gcc-atlas-pipeline', next);
  }
  function addLead(event) {
    event.preventDefault();
    const next = [{ id: Date.now(), company: company.trim(), source_url: source.trim(), signals: [false, false, false, true], demo: false }, ...leads];
    setLeads(next); save('gcc-atlas-pipeline', next); setCompany(''); setSource('');
  }
  const weightTotal = PIPELINE_SIGNALS.reduce((sum, [, weight]) => sum + weight, 0);
  function score(lead) { return Math.round(lead.signals.reduce((sum, active, index) => sum + (active ? PIPELINE_SIGNALS[index][1] : 0), 0) / weightTotal * 100); }
  return <>
    <div className="page-head"><div><h1>GCC pipeline signals</h1><p className="subhead">Record public signals for research leads. A score is signal coverage, not a forecast.</p></div></div>
    <section className="panel workflow-panel"><div className="panel-head"><div><h2>Signal ledger</h2><p>Weights: hiring 3, India leader 3, entity registration 2, press/earnings 1.</p></div><span className="badge amber">LEADS, NOT FORECASTS</span></div>
      <div className="table-wrap"><table><thead><tr><th>Company</th>{PIPELINE_SIGNALS.map(([label, weight]) => <th key={label}>{label} ({weight})</th>)}<th>Coverage</th><th>Source</th></tr></thead><tbody>{leads.map(lead => <tr key={lead.id}><td><b>{lead.company}</b><small>{lead.demo ? 'Fictional sample' : 'Research lead'}</small></td>{PIPELINE_SIGNALS.map(([label], index) => <td key={label}><input aria-label={`${lead.company}: ${label}`} type="checkbox" checked={!!lead.signals[index]} onChange={event => updateSignal(lead.id, index, event.target.checked)} /></td>)}<td>{score(lead)}%</td><td>{lead.source_url ? <a href={lead.source_url} target="_blank" rel="noreferrer">Open <ExternalLink size={12} /></a> : <span className="muted-text">No source</span>}</td></tr>)}</tbody></table></div>
      <form className="evidence-form" onSubmit={addLead}><label>Company<input required value={company} onChange={event => setCompany(event.target.value)} placeholder="Company or research lead" /></label><label>Source URL<input type="url" required value={source} onChange={event => setSource(event.target.value)} placeholder="https://…" /></label><button className="btn primary" type="submit"><Plus size={15} /> Add lead</button></form>
      <div className="disclaimer"><ShieldCheck size={16} /><span>Demo leads are fictional. For real leads, attach a public source and review each signal; coverage does not indicate setup likelihood.</span></div>
    </section>
  </>;
}
